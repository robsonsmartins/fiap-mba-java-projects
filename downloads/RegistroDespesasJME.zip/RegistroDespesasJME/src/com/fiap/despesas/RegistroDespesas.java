package com.fiap.despesas;

import java.util.Date;

import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.DateField;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.ImageItem;
import javax.microedition.lcdui.TextField;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.rms.RecordStore;

public class RegistroDespesas extends MIDlet implements CommandListener {

	private Form frmPrincipal;
	private Image imgLogoFiap;
	private ImageItem imgItemLogo;
	private ChoiceGroup fDespesa;
	private Image imgDespesaRefeicao;
	private Image imgDespesaTransporte;
	private Image imgDespesaOutra;
	private TextField fValor;
	private DateField fData;
	private ChoiceGroup fFormaPagamento;
	private Image imgFormaPagDinheiro;
	private Image imgFormaPagCheque;
	private Image imgFormaPagCartao;
	private Command btnSalvar;
	private Command btnSair;

	public RegistroDespesas() {
		try {
			frmPrincipal = new Form("Registro de Despesas");

			imgLogoFiap = Image.createImage("/logofiap.png");
			imgItemLogo =
				new ImageItem(null,imgLogoFiap,ImageItem.LAYOUT_DEFAULT,"FIAP");

			imgDespesaRefeicao   = Image.createImage("/despesa/refeicao.png");
			imgDespesaTransporte = Image.createImage("/despesa/transporte.png");
			imgDespesaOutra      = Image.createImage("/despesa/outra.png");
			
			fDespesa = new ChoiceGroup("Despesa", ChoiceGroup.EXCLUSIVE);
			fDespesa.append("Refeicao", imgDespesaRefeicao);
			fDespesa.append("Transporte", imgDespesaTransporte);
			fDespesa.append("Outra", imgDespesaOutra);
			
			fValor = new TextField("Valor (R$)", "", 20, TextField.DECIMAL);
			
			fData = new DateField("Data", DateField.DATE);
			fData.setDate(new Date());
			
			imgFormaPagDinheiro = Image.createImage("/formaPag/dinheiro.png");
			imgFormaPagCheque   = Image.createImage("/formaPag/cheque.png");
			imgFormaPagCartao   = Image.createImage("/formaPag/cartao.png");
		
			fFormaPagamento = new ChoiceGroup("Forma Pagamento", ChoiceGroup.EXCLUSIVE);
			fFormaPagamento.append("Dinheiro", imgFormaPagDinheiro);
			fFormaPagamento.append("Cheque", imgFormaPagCheque);
			fFormaPagamento.append("Cartao", imgFormaPagCartao);
			
			btnSalvar = new Command("Salvar", Command.OK, 0);
			btnSair   = new Command("Sair", Command.EXIT, 0);
			
			frmPrincipal.append(imgItemLogo);
			frmPrincipal.append(fDespesa);
			frmPrincipal.append(fValor);
			frmPrincipal.append(fData);
			frmPrincipal.append(fFormaPagamento);
			
			frmPrincipal.addCommand(btnSalvar);
			frmPrincipal.addCommand(btnSair);
			
			frmPrincipal.setCommandListener(this);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

	protected void pauseApp() {
	}

	protected void startApp() throws MIDletStateChangeException {
		Display.getDisplay(this).setCurrent(frmPrincipal);
	}

	public void commandAction(Command c, Displayable d) {
		if (c == btnSalvar) {
			salvarRegistro();
		} else if (c == btnSair) {
			notifyDestroyed();
		}
	}
	
	private void salvarRegistro() {
		Alert alerta = new Alert("Aviso");
		alerta.setTimeout(4000);

		try {

			String dado =
				fDespesa.getString(fDespesa.getSelectedIndex()) + ":" +
				fValor.getString() + ":" +
				fData.getDate() + ":" +
				fFormaPagamento.getString(fFormaPagamento.getSelectedIndex());

			System.out.println(dado);
			
			RecordStore tab = RecordStore.openRecordStore("despesa",true);
			tab.addRecord(dado.getBytes(), 0, dado.length());
			tab.closeRecordStore();
			
			alerta.setString("Gravado com sucesso.");
			
		} catch (Exception e) {

			e.printStackTrace();
			alerta.setString("Erro na gravacao.");
		}

		Display.getDisplay(this).setCurrent(alerta);
	}

}
