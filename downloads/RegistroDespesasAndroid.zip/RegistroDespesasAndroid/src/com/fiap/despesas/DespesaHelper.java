package com.fiap.despesas;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DespesaHelper extends SQLiteOpenHelper {

	public DespesaHelper(Context context) {
		super(context, "despesa.db", null, 1);	
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		String sql =
			String.format("CREATE TABLE %s (%s, %s, %s, %s, %s)",
				"TAB_DESPESA",
				"COD_DESPESA INTEGER PRIMARY KEY AUTOINCREMENT",
				"DESPESA INTEGER",
				"VALOR REAL",
				"DATA TEXT",
				"FORMA INTEGER");
		db.execSQL(sql);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS TAB_DESPESA");
		onCreate(db);
	}

}
