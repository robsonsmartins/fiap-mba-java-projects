package com.fiap.despesas;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

public class DespesaDAO {

	private SQLiteDatabase db;

	public DespesaDAO(Context c) {
		DespesaHelper dbHelper = new DespesaHelper(c);
		db = c.openOrCreateDatabase("despesa.db", Context.MODE_PRIVATE, null);
		db = dbHelper.getWritableDatabase();
	}
	
	public long inserir(DespesaTO despesa) {
		ContentValues content = new ContentValues();
		content.put("DESPESA", despesa.getDespesa().ordinal());
		content.put("VALOR"  , despesa.getValor());
		content.put("DATA"   , despesa.getData().toString());
		content.put("FORMA"  , despesa.getFormaPag().ordinal());
		long id = db.insert("TAB_DESPESA", "", content);
		return id;
	}

}
