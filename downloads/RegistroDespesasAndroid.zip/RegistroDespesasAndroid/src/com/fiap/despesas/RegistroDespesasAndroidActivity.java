package com.fiap.despesas;

import java.util.Calendar;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.TextView;

import com.fiap.despesas.DespesaTO.Despesa;
import com.fiap.despesas.DespesaTO.FormaPagamento;

public class RegistroDespesasAndroidActivity extends Activity {

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        Button btnSalvar = (Button) findViewById(R.id.btnSalvar);
        btnSalvar.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) { btnSalvarOnClick(v); }
		});    

        Button btnSair = (Button) findViewById(R.id.btnSair);
        btnSair.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) { btnSairOnClick(v); }
		});    
    }

	private void btnSalvarOnClick(View v) {
		AlertDialog.Builder b = new AlertDialog.Builder(this);
    	b.setTitle("Aviso");
    	b.setPositiveButton("OK", null);

    	DespesaDAO despesaDAO = new DespesaDAO(this);
		DespesaTO  despesa    = new DespesaTO();

    	try {
			
			RadioButton fDespesaRefeicao = 
				(RadioButton) findViewById(R.id.fDespesaRefeicao);
			RadioButton fDespesaTransporte = 
				(RadioButton) findViewById(R.id.fDespesaTransporte);
	
			if (fDespesaRefeicao.isChecked()) {
				despesa.setDespesa(Despesa.REFEICAO);
			} else if (fDespesaTransporte.isChecked()) {
				despesa.setDespesa(Despesa.TRANSPORTE);
			} else {
				despesa.setDespesa(Despesa.OUTRA);
			}		
			
			TextView fValor =
				(TextView) findViewById(R.id.fValor);
			despesa.setValor(new Float(fValor.getText().toString()));
			
			DatePicker fData = 
				(DatePicker) findViewById(R.id.fData);
			Calendar calendar = Calendar.getInstance();
			calendar.set(fData.getYear(),fData.getMonth(),fData.getDayOfMonth());
			despesa.setData(calendar.getTime());
			
			RadioButton fFormaPagDinheiro = 
				(RadioButton) findViewById(R.id.fFormaPagDinheiro);
			RadioButton fFormaPagCheque = 
				(RadioButton) findViewById(R.id.fFormaPagCheque);
			RadioButton fFormaPagCartao = 
				(RadioButton) findViewById(R.id.fFormaPagCartao);
	
			if (fFormaPagDinheiro.isChecked()) {
				despesa.setFormaPag(FormaPagamento.DINHEIRO);
			} else if (fFormaPagCheque.isChecked()) {
				despesa.setFormaPag(FormaPagamento.CHEQUE);
			} else if (fFormaPagCartao.isChecked()) {
				despesa.setFormaPag(FormaPagamento.CARTAO);
			} else {
				despesa.setFormaPag(FormaPagamento.DINHEIRO);
			}

			long id = despesaDAO.inserir(despesa);
			Log.w("InserirDespesa",new Long(id).toString());

			if (id > 0) {
		    	b.setMessage("Registro gravado com sucesso.");
			} else {
		    	b.setMessage("Erro ao gravar registro.");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
	    	b.setMessage("Erro ao gravar registro.");
		}
    	b.show();
	}
	
	private void btnSairOnClick(View v) {
    	this.finish();
    	System.exit(0);
    }
	
}