package com.fiap.despesas;

import java.util.Date;

public class DespesaTO {
	
	public static enum Despesa {
		REFEICAO, TRANSPORTE, OUTRA;
	}
	
	public static enum FormaPagamento {
		DINHEIRO, CHEQUE, CARTAO;
	}
	
	private Despesa despesa;
	private float valor;
	private Date data;
	private FormaPagamento formaPag;
	
	public Despesa getDespesa() {
		return despesa;
	}
	public void setDespesa(Despesa despesa) {
		this.despesa = despesa;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}
	public FormaPagamento getFormaPag() {
		return formaPag;
	}
	public void setFormaPag(FormaPagamento formaPag) {
		this.formaPag = formaPag;
	}
}
