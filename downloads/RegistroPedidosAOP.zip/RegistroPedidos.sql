-- MySQL dump 10.13  Distrib 5.5.9, for Win32 (x86)
--
-- Host: localhost    Database: regpedidos
-- ------------------------------------------------------
-- Server version	5.5.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `regpedidos`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `regpedidos` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `regpedidos`;

--
-- Table structure for table `tb_cliente`
--

DROP TABLE IF EXISTS `tb_cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_cliente`
--
-- ORDER BY:  `idCliente`

LOCK TABLES `tb_cliente` WRITE;
/*!40000 ALTER TABLE `tb_cliente` DISABLE KEYS */;
INSERT INTO `tb_cliente` (`idCliente`, `nome`, `tipo`) VALUES (1,'Fabio Martins',0),(2,'Robson Martins',1),(3,'Christiny Belini',0),(4,'Adriana Del Nero',1),(5,'Marcos Macedo',1);
/*!40000 ALTER TABLE `tb_cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item_pedido`
--

DROP TABLE IF EXISTS `tb_item_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item_pedido` (
  `idItem` int(11) NOT NULL AUTO_INCREMENT,
  `desconto` float NOT NULL,
  `quantidade` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `idProduto` int(11) NOT NULL,
  PRIMARY KEY (`idItem`),
  KEY `FK64D5C5A07B56F66F` (`idProduto`),
  KEY `FK64D5C5A086A3526D` (`idPedido`),
  CONSTRAINT `FK64D5C5A07B56F66F` FOREIGN KEY (`idProduto`) REFERENCES `tb_produto` (`idProduto`),
  CONSTRAINT `FK64D5C5A086A3526D` FOREIGN KEY (`idPedido`) REFERENCES `tb_pedido` (`idPedido`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item_pedido`
--
-- ORDER BY:  `idItem`

LOCK TABLES `tb_item_pedido` WRITE;
/*!40000 ALTER TABLE `tb_item_pedido` DISABLE KEYS */;
INSERT INTO `tb_item_pedido` (`idItem`, `desconto`, `quantidade`, `idPedido`, `idProduto`) VALUES (1,0,1,7,1),(2,0,2,7,2),(3,0,3,7,3),(4,0,1,6,3),(5,0,1,5,1),(6,0,10,4,2),(7,0,1,1,1),(8,0,3,2,2),(9,0,1,3,3),(10,0,1,6,3),(25,0,1,6,1),(26,0,1,8,4),(27,0,1,8,6),(28,0,1,9,4),(29,0,5,9,1),(30,0,2,10,5),(31,5,1,11,2),(32,5,1,11,3),(33,5,1,11,4),(34,5,1,11,5),(35,5,1,11,6),(36,5,6,11,2),(37,5,3,11,3),(38,5,1,11,1),(39,5,2,11,2),(40,5,1,11,2),(41,5,1,11,6),(42,5,1,11,3),(43,5,1,11,3),(44,5,1,11,5),(45,5,1,11,5),(46,5,1,11,5),(47,5,1,11,5),(48,5,1,11,5),(49,5,1,11,5);
/*!40000 ALTER TABLE `tb_item_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pedido`
--

DROP TABLE IF EXISTS `tb_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_pedido` (
  `idPedido` int(11) NOT NULL AUTO_INCREMENT,
  `data` datetime DEFAULT NULL,
  `desconto` float NOT NULL,
  `finalizado` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  PRIMARY KEY (`idPedido`),
  KEY `FK59828E366D26471` (`idCliente`),
  CONSTRAINT `FK59828E366D26471` FOREIGN KEY (`idCliente`) REFERENCES `tb_cliente` (`idCliente`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pedido`
--
-- ORDER BY:  `idPedido`

LOCK TABLES `tb_pedido` WRITE;
/*!40000 ALTER TABLE `tb_pedido` DISABLE KEYS */;
INSERT INTO `tb_pedido` (`idPedido`, `data`, `desconto`, `finalizado`, `idCliente`) VALUES (1,'2012-01-04 22:22:00',0,1,3),(2,'2012-01-04 22:24:28',0,1,1),(3,'2012-01-04 22:26:05',0,0,3),(4,'2012-01-04 22:27:51',0,0,2),(5,'2012-01-04 22:29:48',0,0,1),(6,'2012-01-04 22:47:54',0,0,4),(7,'2012-01-04 22:34:52',0,1,3),(8,'2012-01-04 22:47:54',0,1,4),(9,'2012-01-13 15:01:21',0,0,5),(10,'2012-01-15 13:25:28',0,0,5),(11,'2012-01-15 15:10:00',0,0,2);
/*!40000 ALTER TABLE `tb_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_produto`
--

DROP TABLE IF EXISTS `tb_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_produto` (
  `idProduto` int(11) NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) DEFAULT NULL,
  `valor` float NOT NULL,
  PRIMARY KEY (`idProduto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_produto`
--
-- ORDER BY:  `idProduto`

LOCK TABLES `tb_produto` WRITE;
/*!40000 ALTER TABLE `tb_produto` DISABLE KEYS */;
INSERT INTO `tb_produto` (`idProduto`, `descricao`, `valor`) VALUES (1,'Aspecto - a Arte de Pensar Diferente',150),(2,'Java para Dummies',50),(3,'Aprenda Java em 21 Dias',80),(4,'JBoss Manual - The Guide',220),(5,'Java - Guia de Referência Rápida',45),(6,'Java na Web - A Bíblia',210);
/*!40000 ALTER TABLE `tb_produto` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-01-15 17:12:41
