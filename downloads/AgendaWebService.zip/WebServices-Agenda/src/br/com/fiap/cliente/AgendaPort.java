package br.com.fiap.cliente;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import br.com.fiap.agenda.Contato;
import br.com.fiap.ws.AgendaServer;

/** 
 * Classe do Gerenciador de Agenda, consome o WebService AgendaServer 
 */
public class AgendaPort implements AgendaServer {
	
	/* strings para conexao ao WebService */
	private static final String WEB_SERVICE_WSDL_URL   = "http://localhost:9876/agenda?wsdl";  
	private static final String WEB_SERVICE_NAMESPACE  = "http://ws.fiap.com.br/";  
	private static final String WEB_SERVICE_LOCAL_PART = "AgendaServerImplService";  
	
	/* objeto obtido via RPC do WebService */
	private AgendaServer agendaServerPort;
	
	/** Construtor. */
	public AgendaPort() {
		try {
			
			URL url = new URL(WEB_SERVICE_WSDL_URL);
			QName qName = new QName(WEB_SERVICE_NAMESPACE, WEB_SERVICE_LOCAL_PART);
			
			Service service  = Service.create(url, qName);
			agendaServerPort = service.getPort(AgendaServer.class);
			
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean inserir(Contato contato) {
		return agendaServerPort.inserir(contato);
	}

	@Override
	public boolean excluir(String email) {
		return agendaServerPort.excluir(email);
	}

	@Override
	public Contato consultar(String email) {
		return agendaServerPort.consultar(email);
	}

	@Override
	public Contato[] listar() {
		return agendaServerPort.listar();
	}
	
}
