package br.com.fiap.ws;

import javax.xml.ws.Endpoint;

/**
 * Classe "publisher" do WebService
 */
public class AgendaPublisher {
	
	/* url de conexao ao WebService Agenda */
	private static final String WEB_SERVICE_URL = "http://127.0.0.1:9876/agenda";  

	/**
	 * Metodo principal da aplicacao.
	 * @param args Argumentos de linha de comando
	 */
	public static void main(String[] args) {
		
		Endpoint.publish(WEB_SERVICE_URL, new AgendaServerImpl());
	}

}
