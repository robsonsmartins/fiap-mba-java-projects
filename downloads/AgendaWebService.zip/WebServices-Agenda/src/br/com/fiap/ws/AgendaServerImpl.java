package br.com.fiap.ws;

import java.util.List;

import javax.jws.WebService;

import br.com.fiap.agenda.Contato;
import br.com.fiap.dao.ContatoDAO;

/**
 * Implementacao do WebService AgendaServer
 */
@WebService(endpointInterface = "br.com.fiap.ws.AgendaServer")
public class AgendaServerImpl implements AgendaServer {


	@Override
	public boolean inserir(Contato contato) {		
		ContatoDAO dao = new ContatoDAO();
		return dao.inserir(contato);
	}

	@Override
	public boolean excluir(String email) {	
		ContatoDAO dao = new ContatoDAO();		
		return dao.excluir(email);
	}

	@Override
	public Contato consultar(String email) {

		ContatoDAO dao = new ContatoDAO();	

		Contato contato = dao.localizar(email);		
		if (contato != null) {
			return contato;
		} else {
			return new Contato();
		}
	}

	@Override
	public Contato[] listar() {

		ContatoDAO dao = new ContatoDAO();
		Contato[] contatoArray;
		List<Contato> listContato = dao.listar();
		
		if (listContato != null) {
			contatoArray = new Contato[listContato.size()];

			int i = 0;
			for (Contato contato: listContato) {
				contatoArray[i] = contato;
				i++;
			}
			
		} else {
			contatoArray = new Contato[0];
		}
		
		return contatoArray;
	}

}
