package br.com.fiap.ws;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import br.com.fiap.agenda.Contato;

/**
 * Interface que define os metodos do WebService "Agenda"
 */
@WebService
@SOAPBinding(style=Style.RPC)
public interface AgendaServer {
	
	/**
	 * Insere um contato
	 * @param contato Contato a ser inserido
	 * @return True se bem sucedido, false se houve erro ou contato ja' existe.
	 */
	@WebMethod boolean inserir(Contato contato);

	/**
	 * Exclui um contato
	 * @param email Email do contato a ser removido
	 * @return True se bem sucedido, false se houve erro ou contato nao existe.
	 */
	@WebMethod boolean excluir(String email);

	/**
	 * Consulta e retorna um contato
	 * @param email Email do contato a ser consultado
	 * @return Objeto da classe Contato; "preenchido" se bem sucedido, "vazio" se houve erro.
	 */
	@WebMethod Contato consultar(String email);
	
	/**
	 * Lista contatos
	 * @return Lista de contatos ou lista vazia se houve erro.
	 */
	@WebMethod Contato[] listar();

}
