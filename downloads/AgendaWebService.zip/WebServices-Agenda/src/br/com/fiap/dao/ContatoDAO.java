package br.com.fiap.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import br.com.fiap.agenda.Contato;
/**
 * Classe de manipulacao de objetos persistidos via JPA
 * Objetos da classe bean Contato
 */
public class ContatoDAO extends GenericDAO<Contato> {

	/**
	 * Exclui um Contato persistido
	 * @param email Email do contato
	 * @return True se bem sucedido, false se houve erro.
	 */
	public boolean excluir(String email) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction t = em.getTransaction();
		Contato obj = null;
		boolean result = false;

		try {

			t.begin();
			Query q = em.createQuery("from Contato where email = :email");
			q.setParameter("email", email);
			obj = (Contato) q.getSingleResult();
			em.remove(obj);
			t.commit();
			result = true;

		} catch (Exception e) {

			if (debugInfo) {
				e.printStackTrace();
			}
			if (t.isActive()) t.rollback();

		} finally {

			em.close();
		}
		
		return result;
	}

	/**
	 * Localiza um contato persistido pelo email
	 * @param email Email do contato
	 * @return Objeto persistido
	 */
	public Contato localizar(String email) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction t = em.getTransaction();
		Contato obj = new Contato();

		try {

			t.begin();
			Query query = em.createQuery("from Contato where email like :email");
			query.setParameter("email", email);
			obj = (Contato) query.getSingleResult();
			t.commit();

		} catch (Exception e) {

			if (debugInfo) {
				e.printStackTrace();
			}
			if (t.isActive()) t.rollback();

		} finally {

			em.close();
		}

		return obj;
	}
}
