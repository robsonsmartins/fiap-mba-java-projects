/**
 * Contem as classes que implementam um LoginModule JAAS
 *   que consulta o Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.fiap.tcc.sicid.jaas;