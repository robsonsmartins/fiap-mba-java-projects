/**
 * Contem as classes que implementam a camada de controle (controller)
 *   do Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package sicid.web.controller;