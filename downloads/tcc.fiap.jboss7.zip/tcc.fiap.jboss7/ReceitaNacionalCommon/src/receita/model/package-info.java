/**
 * Contem as classes que implementam a camada de modelo (model) da
 *   Receita Nacional.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package receita.model;