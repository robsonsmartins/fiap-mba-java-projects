/**
 * Contem as classes que representam entidades ou conjuntos de dados
 *  usados pela Receita Nacional.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package receita.bean;