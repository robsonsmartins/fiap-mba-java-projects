/**
 * Contem as classes que manipulam dados usados
 *   pela Receita Nacional.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package receita.dao;