/**
 * Contem as classes que implementam funcionalidades uteis aos
 *   sistemas que compoem o Trabalho de Conclusao do Curso MBA/SCJ, pela FIAP.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package com.robsonmartins.fiap.tcc.util;