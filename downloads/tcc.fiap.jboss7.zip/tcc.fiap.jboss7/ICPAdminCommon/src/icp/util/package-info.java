/**
 * Contem as classes que implementam funcionalidades uteis ao sistema.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package icp.util;