/**
 * Contem as classes que representam entidades ou conjuntos de dados para
 *  o gerenciamento de autoridades certificadoras.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package icp.bean;