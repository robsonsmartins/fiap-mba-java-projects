/**
 * Contem as classes que implementam a camada de modelo (model) da
 *   aplicacao de gerenciamento de autoridades certificadoras.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package icp.model;