/**
 * Contem as classes que manipulam dados usados
 *   pelo Banco Seguro.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package banco.dao;