/**
 * Contem as classes que implementam o Servico Web e o Cliente do
 *   Banco Seguro.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package banco.ws;