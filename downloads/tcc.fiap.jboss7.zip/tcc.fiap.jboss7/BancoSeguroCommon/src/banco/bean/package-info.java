/**
 * Contem as classes que representam entidades ou conjuntos de dados
 *  usados pelo Banco Seguro.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package banco.bean;