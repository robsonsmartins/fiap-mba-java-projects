/**
 * Contem as classes que implementam a camada de modelo (model) do
 *   Banco Seguro.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package banco.model;