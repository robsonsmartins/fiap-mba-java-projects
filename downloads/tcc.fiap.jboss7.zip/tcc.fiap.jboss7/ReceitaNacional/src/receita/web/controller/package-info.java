/**
 * Contem as classes que implementam a camada de controle (controller)
 *   da Receita Nacional.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package receita.web.controller;