/**
 * Contem as classes que representam entidades ou conjuntos de dados
 *  usados pelo Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package sicid.bean;