/**
 * Contem as classes que implementam a camada de modelo (model) do
 *   Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package sicid.model;