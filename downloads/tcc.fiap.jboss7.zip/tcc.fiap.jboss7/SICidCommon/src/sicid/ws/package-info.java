/**
 * Contem as classes que implementam o Servico Web e o Cliente do
 *   Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package sicid.ws;