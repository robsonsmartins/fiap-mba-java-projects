/**
 * Contem as classes que manipulam dados usados
 *   pelo Servico de Identificacao do Cidadao (SICid).
 * @author Robson Martins (robson@robsonmartins.com)
 */
package sicid.dao;