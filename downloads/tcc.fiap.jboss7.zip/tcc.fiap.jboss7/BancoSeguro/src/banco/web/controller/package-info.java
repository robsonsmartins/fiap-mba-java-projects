/**
 * Contem as classes que implementam a camada de controle (controller)
 *   do Banco Seguro.
 * @author Robson Martins (robson@robsonmartins.com)
 */
package banco.web.controller;