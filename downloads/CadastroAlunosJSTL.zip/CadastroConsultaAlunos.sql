
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `sistalunos` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `sistalunos`;
DROP TABLE IF EXISTS `TB_DISCIPLINA`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TB_DISCIPLINA` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DESCRICAO` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `TB_DISCIPLINA` WRITE;
/*!40000 ALTER TABLE `TB_DISCIPLINA` DISABLE KEYS */;
INSERT INTO `TB_DISCIPLINA` VALUES (7,'Matematica'),(8,'Fisica'),(9,'Quimica'),(11,'Portugues'),(12,'Filosofia'),(13,'Sociologia'),(14,'Historia'),(15,'Geografia'),(16,'Artes'),(17,'Economia'),(18,'Direito'),(19,'Teologia'),(20,'Marketing'),(21,'Informatica');
/*!40000 ALTER TABLE `TB_DISCIPLINA` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `TB_DISCIPLINA_USUARIO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TB_DISCIPLINA_USUARIO` (
  `ID_USUARIO` varchar(10) NOT NULL,
  `ID_DISCIPLINA` int(10) unsigned NOT NULL,
  `NOTA` float unsigned DEFAULT NULL,
  PRIMARY KEY (`ID_USUARIO`,`ID_DISCIPLINA`),
  KEY `FK_ID_DISCIPLINA` (`ID_DISCIPLINA`),
  CONSTRAINT `FK_ID_DISCIPLINA` FOREIGN KEY (`ID_DISCIPLINA`) REFERENCES `TB_DISCIPLINA` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_ID_USUARIO` FOREIGN KEY (`ID_USUARIO`) REFERENCES `TB_USUARIO` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `TB_DISCIPLINA_USUARIO` WRITE;
/*!40000 ALTER TABLE `TB_DISCIPLINA_USUARIO` DISABLE KEYS */;
INSERT INTO `TB_DISCIPLINA_USUARIO` VALUES ('amarcondes',21,7),('amsouza',21,5),('aromano',7,10),('aromano',8,8),('aromano',9,6),('aromano',11,8),('aromano',12,3.4),('aromano',13,2),('aromano',14,6.5),('aromano',15,5),('aromano',16,9),('aromano',17,7.5),('aromano',18,4),('aromano',19,7),('aromano',20,8),('aromano',21,10),('cgoulart',7,10),('cgoulart',8,10),('cgoulart',9,9),('cgoulart',11,6),('cgoulart',12,1.1),('cgoulart',13,3),('cgoulart',14,5.5),('cgoulart',15,4),('cgoulart',16,4.5),('cgoulart',17,7.5),('cgoulart',18,3.6),('cgoulart',19,5),('cgoulart',20,9),('cgoulart',21,10),('dcastro',21,2),('dfigueira',7,5),('dfigueira',21,4),('ecsantos',21,1),('gmoraes',21,7),('icosta',21,3),('jsouza',21,8.8),('kmonteiro',21,6),('ksilva',21,6.5),('lsantana',21,4.6),('madamasc',21,7),('mferreira',21,6),('mramos',21,4),('ndamasceno',7,10),('ndamasceno',8,7),('ndamasceno',11,8.8),('ndamasceno',12,7.2),('ndamasceno',14,7.8),('ndamasceno',15,9),('ndamasceno',16,8.5),('ndamasceno',17,9),('ndamasceno',18,10),('ndamasceno',19,10),('ndamasceno',21,10),('rcsilva',18,10),('rcsilva',21,10),('rmartins',7,10),('rmartins',8,10),('rmartins',9,4.5),('rmartins',11,9),('rmartins',12,0.5),('rmartins',13,0),('rmartins',14,4.2),('rmartins',15,6.5),('rmartins',16,10),('rmartins',17,7),('rmartins',18,2),('rmartins',19,9.5),('rmartins',20,6),('rmartins',21,10),('rsantos',7,4.8),('rsantos',21,2),('uvsouza',18,8),('uvsouza',21,3),('zadamasc',21,5.2);
/*!40000 ALTER TABLE `TB_DISCIPLINA_USUARIO` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `TB_USUARIO`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TB_USUARIO` (
  `NOME` varchar(255) NOT NULL,
  `SENHA` varchar(10) NOT NULL,
  `NIVEL` int(10) unsigned NOT NULL,
  `ID` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `TB_USUARIO` WRITE;
/*!40000 ALTER TABLE `TB_USUARIO` DISABLE KEYS */;
INSERT INTO `TB_USUARIO` VALUES ('Administrador','ADMIN',0,'ADMIN'),('Awdrey Alcantara Ribeiro Marcondes','amarcondes',1,'amarcondes'),('Ada Mara Moraes de Souza','amsouza',1,'amsouza'),('Adriana Del Nero Romano','aromano',1,'aromano'),('Christiny Belini Goulart','cgoulart',1,'cgoulart'),('Deusa de Castro','dcastro',1,'dcastro'),('Debora Siqueira Figueira','dfigueira',1,'dfigueira'),('Elisabeth Cristiane Alves dos Santos','ecsantos',1,'ecsantos'),('Giselle de Souza Moraes','gmoraes',1,'gmoraes'),('Izabel Costa','icosta',1,'icosta'),('Joyce Oliveira de Souza','jsouza',1,'jsouza'),('Karen Sucupira Chagas Monteiro','kmonteiro',1,'kmonteiro'),('Kemilyn Ferraz Batista da Silva','ksilva',1,'ksilva'),('Luana dos Reis Santana','lsantana',1,'lsantana'),('Miriam Andressa Rodrigues Damasceno','madamasc',1,'madamasc'),('Magda Roberta Ferreira','mferreira',1,'mferreira'),('Marilu Oliveira Ramos','mramos',1,'mramos'),('Natasha Rodrigues Damasceno','ndamasceno',1,'ndamasceno'),('Rita de Cassia Santos da Silva','rcsilva',1,'rcsilva'),('Robson de Sousa Martins','rmartins',1,'rmartins'),('Raquel Moret dos Santos','rsantos',1,'rsantos'),('Ulda Vasti Moraes de Souza','uvsouza',1,'uvsouza'),('Zoraide Aline Rodrigues Damasceno','zadamasc',1,'zadamasc');
/*!40000 ALTER TABLE `TB_USUARIO` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

